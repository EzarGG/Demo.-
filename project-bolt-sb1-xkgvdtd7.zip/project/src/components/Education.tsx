import React from 'react';
import { BookOpen, MapPin, Calendar } from 'lucide-react';

const Education: React.FC = () => {
  return (
    <section id="education" className="py-20 bg-slate-50 dark:bg-slate-900">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-slate-800 dark:text-white">
            My <span className="text-indigo-600 dark:text-indigo-400">Education</span>
          </h2>
          
          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-0 md:left-1/2 transform md:-translate-x-1/2 h-full w-1 bg-indigo-200 dark:bg-indigo-900"></div>
            
            {/* School Card */}
            <div className="relative z-10 mb-16 md:ml-auto md:mr-auto md:w-1/2 md:pr-8 md:pl-0 pl-8">
              <div className="flex flex-col md:items-end">
                <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-lg border-l-4 border-indigo-500 md:border-l-0 md:border-r-4 transform transition-all hover:scale-105 duration-300">
                  <div className="flex items-center mb-4">
                    <BookOpen className="text-indigo-600 dark:text-indigo-400 mr-2" size={24} />
                    <h3 className="text-2xl font-bold text-slate-800 dark:text-white">SMPN 193 Jakarta</h3>
                  </div>
                  
                  <div className="space-y-3 mb-4">
                    <div className="flex items-center">
                      <MapPin className="text-indigo-600 dark:text-indigo-400 mr-2" size={18} />
                      <span className="text-slate-600 dark:text-slate-300">Jakarta, Indonesia</span>
                    </div>
                    <div className="flex items-center">
                      <Calendar className="text-indigo-600 dark:text-indigo-400 mr-2" size={18} />
                      <span className="text-slate-600 dark:text-slate-300">Current Student</span>
                    </div>
                  </div>
                  
                  <p className="text-slate-600 dark:text-slate-300">
                    I'm currently studying at SMPN 193 Jakarta, where I'm developing strong academic foundations
                    while also pursuing my personal interests. The school provides a supportive environment for
                    both academic and personal growth.
                  </p>
                </div>
                
                {/* Timeline dot */}
                <div className="absolute left-0 md:left-auto md:right-0 top-6 md:translate-x-1/2 -translate-x-1/2 w-5 h-5 rounded-full bg-indigo-600 border-4 border-white dark:border-slate-900"></div>
              </div>
            </div>
            
            {/* School Activities */}
            <div className="relative z-10 mb-16 md:mr-auto md:w-1/2 md:pl-8 pl-8">
              <div className="flex flex-col">
                <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-lg border-l-4 border-indigo-500 transform transition-all hover:scale-105 duration-300">
                  <h3 className="text-2xl font-bold text-slate-800 dark:text-white mb-4">School Activities</h3>
                  
                  <ul className="space-y-3 text-slate-600 dark:text-slate-300">
                    <li className="flex items-start">
                      <span className="text-indigo-600 dark:text-indigo-400 mr-2">•</span>
                      <span>Actively participate in classroom discussions and group projects</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-indigo-600 dark:text-indigo-400 mr-2">•</span>
                      <span>Member of the school's computer club, exploring technology and digital skills</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-indigo-600 dark:text-indigo-400 mr-2">•</span>
                      <span>Participated in several school competitions and events</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-indigo-600 dark:text-indigo-400 mr-2">•</span>
                      <span>Working on improving both academic performance and personal development</span>
                    </li>
                  </ul>
                </div>
                
                {/* Timeline dot */}
                <div className="absolute left-0 md:left-0 top-6 -translate-x-1/2 w-5 h-5 rounded-full bg-indigo-600 border-4 border-white dark:border-slate-900"></div>
              </div>
            </div>
            
            {/* Future Goals */}
            <div className="relative z-10 md:ml-auto md:mr-auto md:w-1/2 md:pr-8 md:pl-0 pl-8">
              <div className="flex flex-col md:items-end">
                <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-lg border-l-4 border-indigo-500 md:border-l-0 md:border-r-4 transform transition-all hover:scale-105 duration-300">
                  <h3 className="text-2xl font-bold text-slate-800 dark:text-white mb-4">Learning Journey</h3>
                  
                  <p className="text-slate-600 dark:text-slate-300 mb-4">
                    My educational journey is focused on building a strong foundation across all subjects while
                    exploring my interest in technology and digital media. I'm particularly drawn to:
                  </p>
                  
                  <ul className="space-y-3 text-slate-600 dark:text-slate-300">
                    <li className="flex items-start">
                      <span className="text-indigo-600 dark:text-indigo-400 mr-2">•</span>
                      <span>Mathematics and logical problem-solving</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-indigo-600 dark:text-indigo-400 mr-2">•</span>
                      <span>Technology and computer science basics</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-indigo-600 dark:text-indigo-400 mr-2">•</span>
                      <span>Digital creativity and media</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-indigo-600 dark:text-indigo-400 mr-2">•</span>
                      <span>Developing English language skills</span>
                    </li>
                  </ul>
                </div>
                
                {/* Timeline dot */}
                <div className="absolute left-0 md:left-auto md:right-0 top-6 md:translate-x-1/2 -translate-x-1/2 w-5 h-5 rounded-full bg-indigo-600 border-4 border-white dark:border-slate-900"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Education;