import React, { useState } from 'react';
import { Gamepad2, Trophy, Users, Clock } from 'lucide-react';

const Gaming: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'favorite' | 'achievements' | 'platforms'>('favorite');
  
  const games = [
    {
      id: 1,
      title: "Minecraft",
      description: "A sandbox game focused on creativity and survival",
      image: "https://images.pexels.com/photos/7360387/pexels-photo-7360387.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      genre: "Sandbox, Survival",
      platform: "PC, Mobile, Console"
    },
    {
      id: 2,
      title: "Fortnite",
      description: "Battle royale game with building mechanics",
      image: "https://images.pexels.com/photos/6498982/pexels-photo-6498982.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      genre: "Battle Royale, Action",
      platform: "PC, Mobile, Console"
    },
    {
      id: 3,
      title: "Mobile Legends",
      description: "Mobile MOBA game with team-based gameplay",
      image: "https://images.pexels.com/photos/4009598/pexels-photo-4009598.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      genre: "MOBA, Strategy",
      platform: "Mobile"
    },
    {
      id: 4,
      title: "PUBG Mobile",
      description: "Battle royale game with realistic gameplay",
      image: "https://images.pexels.com/photos/7915273/pexels-photo-7915273.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      genre: "Battle Royale, Action",
      platform: "Mobile"
    }
  ];
  
  const achievements = [
    {
      id: 1,
      title: "Tournament Finalist",
      description: "Reached the finals in a local Mobile Legends tournament",
      icon: <Trophy className="text-yellow-500" size={24} />
    },
    {
      id: 2,
      title: "Diamond Rank",
      description: "Achieved Diamond rank in Mobile Legends ranked season",
      icon: <Trophy className="text-blue-500" size={24} />
    },
    {
      id: 3,
      title: "Minecraft Master Builder",
      description: "Created an impressive city build in Minecraft",
      icon: <Trophy className="text-green-500" size={24} />
    },
    {
      id: 4,
      title: "Team Captain",
      description: "Led a gaming team in school competitions",
      icon: <Users className="text-purple-500" size={24} />
    }
  ];
  
  const platforms = [
    {
      id: 1,
      name: "Mobile Gaming",
      description: "Primary gaming platform for on-the-go play",
      devices: "Android Smartphone",
      favGames: "Mobile Legends, PUBG Mobile, Call of Duty Mobile"
    },
    {
      id: 2,
      name: "PC Gaming",
      description: "Weekend gaming sessions at home or internet cafes",
      devices: "Home PC, Internet Cafe",
      favGames: "Minecraft, Fortnite, Valorant"
    }
  ];

  return (
    <section id="gaming" className="py-20 bg-white dark:bg-slate-800">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-800 dark:text-white inline-flex items-center justify-center">
              <Gamepad2 className="text-indigo-600 dark:text-indigo-400 mr-3" size={32} />
              <span>My Gaming <span className="text-indigo-600 dark:text-indigo-400">Journey</span></span>
            </h2>
            <p className="text-slate-600 dark:text-slate-300 mt-4 max-w-2xl mx-auto">
              Gaming is more than just a hobby for me—it's a passion that helps me connect with friends, 
              exercise creativity, and develop strategic thinking.
            </p>
          </div>
          
          {/* Tab Navigation */}
          <div className="flex justify-center mb-8">
            <div className="inline-flex bg-slate-100 dark:bg-slate-700 rounded-lg p-1">
              <button
                onClick={() => setActiveTab('favorite')}
                className={`px-4 py-2 rounded-md text-sm font-medium ${
                  activeTab === 'favorite'
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-600 dark:text-slate-300 hover:text-indigo-600 dark:hover:text-indigo-400'
                } transition-colors duration-200`}
              >
                Favorite Games
              </button>
              <button
                onClick={() => setActiveTab('achievements')}
                className={`px-4 py-2 rounded-md text-sm font-medium ${
                  activeTab === 'achievements'
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-600 dark:text-slate-300 hover:text-indigo-600 dark:hover:text-indigo-400'
                } transition-colors duration-200`}
              >
                Achievements
              </button>
              <button
                onClick={() => setActiveTab('platforms')}
                className={`px-4 py-2 rounded-md text-sm font-medium ${
                  activeTab === 'platforms'
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-600 dark:text-slate-300 hover:text-indigo-600 dark:hover:text-indigo-400'
                } transition-colors duration-200`}
              >
                Platforms
              </button>
            </div>
          </div>
          
          {/* Tab Content */}
          <div className="mt-8">
            {/* Favorite Games Tab */}
            {activeTab === 'favorite' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {games.map((game) => (
                  <div 
                    key={game.id} 
                    className="bg-slate-50 dark:bg-slate-700 rounded-xl overflow-hidden shadow-lg transform transition-all hover:scale-105 duration-300"
                  >
                    <div 
                      className="h-48 bg-cover bg-center" 
                      style={{ backgroundImage: `url(${game.image})` }}
                    >
                      <div className="w-full h-full bg-gradient-to-t from-black/70 to-transparent flex items-end">
                        <h3 className="text-white text-xl font-bold p-4">{game.title}</h3>
                      </div>
                    </div>
                    <div className="p-4">
                      <p className="text-slate-600 dark:text-slate-300 mb-3">{game.description}</p>
                      <div className="flex flex-wrap gap-2">
                        <span className="px-3 py-1 bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-300 text-xs font-medium rounded-full">
                          {game.genre}
                        </span>
                        <span className="px-3 py-1 bg-purple-100 dark:bg-purple-900/50 text-purple-600 dark:text-purple-300 text-xs font-medium rounded-full">
                          {game.platform}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
            
            {/* Achievements Tab */}
            {activeTab === 'achievements' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {achievements.map((achievement) => (
                  <div 
                    key={achievement.id} 
                    className="bg-slate-50 dark:bg-slate-700 rounded-xl p-6 shadow-lg transform transition-all hover:scale-105 duration-300"
                  >
                    <div className="flex items-center mb-3">
                      <div className="p-2 bg-white dark:bg-slate-800 rounded-lg mr-3">
                        {achievement.icon}
                      </div>
                      <h3 className="text-xl font-bold text-slate-800 dark:text-white">{achievement.title}</h3>
                    </div>
                    <p className="text-slate-600 dark:text-slate-300">{achievement.description}</p>
                  </div>
                ))}
              </div>
            )}
            
            {/* Platforms Tab */}
            {activeTab === 'platforms' && (
              <div className="space-y-6">
                {platforms.map((platform) => (
                  <div 
                    key={platform.id} 
                    className="bg-slate-50 dark:bg-slate-700 rounded-xl p-6 shadow-lg transform transition-all hover:scale-105 duration-300"
                  >
                    <h3 className="text-xl font-bold text-slate-800 dark:text-white mb-3">{platform.name}</h3>
                    <p className="text-slate-600 dark:text-slate-300 mb-4">{platform.description}</p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <h4 className="font-medium text-indigo-600 dark:text-indigo-400 mb-1">Devices</h4>
                        <p className="text-slate-600 dark:text-slate-300">{platform.devices}</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-indigo-600 dark:text-indigo-400 mb-1">Favorite Games</h4>
                        <p className="text-slate-600 dark:text-slate-300">{platform.favGames}</p>
                      </div>
                    </div>
                  </div>
                ))}
                
                <div className="bg-indigo-50 dark:bg-indigo-900/30 rounded-xl p-6 border border-indigo-200 dark:border-indigo-800 mt-8">
                  <div className="flex items-start">
                    <Clock className="text-indigo-600 dark:text-indigo-400 mt-1 mr-3 flex-shrink-0" size={24} />
                    <div>
                      <h3 className="text-lg font-medium text-slate-800 dark:text-white mb-2">My Gaming Schedule</h3>
                      <p className="text-slate-600 dark:text-slate-300">
                        I balance my gaming time with schoolwork and other responsibilities. I typically play:
                      </p>
                      <ul className="mt-2 space-y-1 text-slate-600 dark:text-slate-300">
                        <li>• Weekdays: 1-2 hours after completing homework</li>
                        <li>• Weekends: 3-4 hours, often playing with friends</li>
                        <li>• School holidays: Extended gaming sessions and trying new games</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Gaming;