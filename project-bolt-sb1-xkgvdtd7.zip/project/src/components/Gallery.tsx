import React, { useState } from 'react';
import { X } from 'lucide-react';

const Gallery: React.FC = () => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  
  const galleryImages = [
    {
      id: 1,
      url: "https://images.pexels.com/photos/7915282/pexels-photo-7915282.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      alt: "Gaming setup with monitor and keyboard",
      category: "Setup"
    },
    {
      id: 2,
      url: "https://images.pexels.com/photos/6498305/pexels-photo-6498305.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      alt: "Person playing on mobile phone",
      category: "Mobile Gaming"
    },
    {
      id: 3,
      url: "https://images.pexels.com/photos/442576/pexels-photo-442576.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      alt: "Controller on a table",
      category: "Gaming"
    },
    {
      id: 4,
      url: "https://images.pexels.com/photos/159490/school-font-classroom-chalkboard-159490.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      alt: "School classroom",
      category: "School"
    },
    {
      id: 5,
      url: "https://images.pexels.com/photos/7915265/pexels-photo-7915265.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      alt: "Gaming keyboard with RGB lighting",
      category: "Setup"
    },
    {
      id: 6,
      url: "https://images.pexels.com/photos/6805855/pexels-photo-6805855.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      alt: "Person playing games with friends",
      category: "Friends"
    },
    {
      id: 7,
      url: "https://images.pexels.com/photos/5582867/pexels-photo-5582867.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      alt: "School building exterior",
      category: "School"
    },
    {
      id: 8,
      url: "https://images.pexels.com/photos/6805816/pexels-photo-6805816.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      alt: "Two friends playing video games",
      category: "Friends"
    }
  ];

  return (
    <section id="gallery" className="py-20 bg-slate-50 dark:bg-slate-900">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-slate-800 dark:text-white">
            Photo <span className="text-indigo-600 dark:text-indigo-400">Gallery</span>
          </h2>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {galleryImages.map((image) => (
              <div 
                key={image.id} 
                className="relative group overflow-hidden rounded-lg aspect-square cursor-pointer"
                onClick={() => setSelectedImage(image.url)}
              >
                <img 
                  src={image.url} 
                  alt={image.alt} 
                  className="object-cover w-full h-full transform transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
                  <div className="p-3 w-full">
                    <span className="text-white text-sm font-medium">{image.alt}</span>
                    <div className="mt-1">
                      <span className="inline-block px-2 py-1 bg-indigo-600/80 rounded-full text-white text-xs">
                        {image.category}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          {/* Image Lightbox */}
          {selectedImage && (
            <div 
              className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4"
              onClick={() => setSelectedImage(null)}
            >
              <button 
                className="absolute top-4 right-4 text-white hover:text-indigo-400 transition-colors"
                onClick={() => setSelectedImage(null)}
              >
                <X size={32} />
              </button>
              <div 
                className="relative max-w-4xl max-h-[90vh]"
                onClick={(e) => e.stopPropagation()}
              >
                <img 
                  src={selectedImage} 
                  alt="Enlarged gallery image" 
                  className="max-w-full max-h-[90vh] object-contain"
                />
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default Gallery;