import React from 'react';
import { Heart, Github, Linkedin, Instagram } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

const Footer: React.FC = () => {
  const { theme } = useTheme();
  
  return (
    <footer className="bg-slate-800 dark:bg-slate-950 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-5xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-6 md:mb-0">
              <h2 className="text-2xl font-bold text-indigo-400">Ezar</h2>
              <p className="text-slate-400 mt-2">Student & Gaming Enthusiast</p>
            </div>
            
            <div className="flex space-x-4">
              <a 
                href="#" 
                className="w-10 h-10 rounded-full bg-slate-700 hover:bg-indigo-600 flex items-center justify-center transition-colors duration-200"
                aria-label="Github"
              >
                <Github size={20} />
              </a>
              <a 
                href="#" 
                className="w-10 h-10 rounded-full bg-slate-700 hover:bg-indigo-600 flex items-center justify-center transition-colors duration-200"
                aria-label="LinkedIn"
              >
                <Linkedin size={20} />
              </a>
              <a 
                href="#" 
                className="w-10 h-10 rounded-full bg-slate-700 hover:bg-indigo-600 flex items-center justify-center transition-colors duration-200"
                aria-label="Instagram"
              >
                <Instagram size={20} />
              </a>
            </div>
          </div>
          
          <div className="border-t border-slate-700 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-slate-400 text-sm mb-4 md:mb-0">
              &copy; {new Date().getFullYear()} Ezar's Portfolio. All rights reserved.
            </p>
            
            <div className="flex flex-wrap justify-center gap-4 text-sm text-slate-400">
              <a href="#home" className="hover:text-indigo-400 transition-colors">Home</a>
              <a href="#about" className="hover:text-indigo-400 transition-colors">About</a>
              <a href="#education" className="hover:text-indigo-400 transition-colors">Education</a>
              <a href="#gaming" className="hover:text-indigo-400 transition-colors">Gaming</a>
              <a href="#gallery" className="hover:text-indigo-400 transition-colors">Gallery</a>
              <a href="#contact" className="hover:text-indigo-400 transition-colors">Contact</a>
            </div>
          </div>
          
          <div className="mt-6 text-center text-sm text-slate-500 flex items-center justify-center">
            <span>Made with</span>
            <Heart className="mx-1 text-red-500" size={14} />
            <span>in 2025</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;