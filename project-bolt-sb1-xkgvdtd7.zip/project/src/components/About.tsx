import React from 'react';
import { MapPin, Calendar, Heart } from 'lucide-react';

const About: React.FC = () => {
  return (
    <section id="about" className="py-20 bg-white dark:bg-slate-800">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-slate-800 dark:text-white">
            About <span className="text-indigo-600 dark:text-indigo-400">Me</span>
          </h2>
          
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div className="bg-slate-100 dark:bg-slate-700 rounded-2xl overflow-hidden shadow-xl transform transition-all hover:scale-105 duration-300">
              <div className="h-64 bg-gradient-to-r from-indigo-500 to-purple-600 relative">
                <div className="absolute inset-0 bg-[url('https://images.pexels.com/photos/2531353/pexels-photo-2531353.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2')] bg-cover bg-center opacity-60 mix-blend-overlay"></div>
              </div>
              <div className="p-6">
                <h3 className="text-2xl font-bold text-slate-800 dark:text-white mb-2">Ezar</h3>
                <p className="text-slate-600 dark:text-slate-300 mb-4">
                  A passionate student with a love for gaming and technology.
                </p>
                <div className="flex flex-col space-y-2">
                  <div className="flex items-center">
                    <MapPin className="text-indigo-600 dark:text-indigo-400 mr-2" size={18} />
                    <span className="text-slate-600 dark:text-slate-300">Jakarta Timur, Ujung Menteng</span>
                  </div>
                  <div className="flex items-center">
                    <Calendar className="text-indigo-600 dark:text-indigo-400 mr-2" size={18} />
                    <span className="text-slate-600 dark:text-slate-300">Student</span>
                  </div>
                  <div className="flex items-center">
                    <Heart className="text-indigo-600 dark:text-indigo-400 mr-2" size={18} />
                    <span className="text-slate-600 dark:text-slate-300">Gaming, Technology</span>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="space-y-6">
              <div className="bg-slate-50 dark:bg-slate-700 p-6 rounded-xl shadow-md">
                <h3 className="text-xl font-semibold text-indigo-600 dark:text-indigo-400 mb-3">Who I Am</h3>
                <p className="text-slate-600 dark:text-slate-300">
                  Hello! I'm Ezar, a student at SMPN 193 Jakarta with a passion for gaming and technology. 
                  I live in Jakarta Timur, specifically in the Ujung Menteng area.
                </p>
              </div>
              
              <div className="bg-slate-50 dark:bg-slate-700 p-6 rounded-xl shadow-md">
                <h3 className="text-xl font-semibold text-indigo-600 dark:text-indigo-400 mb-3">My Interests</h3>
                <p className="text-slate-600 dark:text-slate-300">
                  When I'm not studying, you'll find me immersed in the gaming world. I enjoy playing various 
                  games across different platforms and genres. I'm also interested in learning more about 
                  game development and digital technology.
                </p>
              </div>
              
              <div className="bg-slate-50 dark:bg-slate-700 p-6 rounded-xl shadow-md">
                <h3 className="text-xl font-semibold text-indigo-600 dark:text-indigo-400 mb-3">My Goals</h3>
                <p className="text-slate-600 dark:text-slate-300">
                  I aim to excel in my studies while pursuing my passion for gaming. In the future, 
                  I hope to combine these interests, perhaps in game design, development, or e-sports.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;