import React from 'react';
import { ArrowDown } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section 
      id="home" 
      className="min-h-screen relative flex items-center justify-center pt-16 overflow-hidden"
    >
      <div className="absolute inset-0 bg-gradient-to-br from-indigo-600/20 to-purple-600/20 dark:from-indigo-900/30 dark:to-purple-900/30"></div>
      
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="gaming-particles"></div>
      </div>
      
      <div className="container mx-auto px-4 z-10">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 text-slate-800 dark:text-white animate-fade-in">
            Hello, I'm <span className="text-indigo-600 dark:text-indigo-400">Ezar</span>
          </h1>
          <p className="text-lg md:text-xl text-slate-600 dark:text-slate-300 mb-8 animate-fade-in-delay">
            Student at SMPN 193 Jakarta | Gaming Enthusiast
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4 animate-fade-in-delay-2">
            <a 
              href="#about" 
              className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition-all transform hover:scale-105 shadow-lg"
            >
              Learn About Me
            </a>
            <a 
              href="#gaming" 
              className="px-6 py-3 bg-transparent border-2 border-indigo-600 dark:border-indigo-400 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-600/10 rounded-lg transition-all transform hover:scale-105"
            >
              Explore My Gaming
            </a>
          </div>
        </div>
      </div>
      
      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <a href="#about" className="text-slate-600 dark:text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400">
          <ArrowDown size={32} />
        </a>
      </div>
    </section>
  );
};

export default Hero;